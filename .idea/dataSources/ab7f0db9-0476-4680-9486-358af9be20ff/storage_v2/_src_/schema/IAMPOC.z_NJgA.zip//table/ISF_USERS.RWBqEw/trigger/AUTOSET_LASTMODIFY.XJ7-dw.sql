create trigger AUTOSET_LASTMODIFY
  before insert or update
  on ISF_USERS
  for each row
  DECLARE
tmpVar NUMBER;
/******************************************************************************
   NAME:       AutoSet_LastModify_ISF_USERS
   PURPOSE:    

   REVISIONS:
   Ver        Date        Author           Description
   ---------  ----------  ---------------  ------------------------------------
   1.0        25/Jun/18      pvanh       1. Created this trigger.

   NOTES:

   Automatically available Auto Replace Keywords:
      Object Name:     AutoSet_LastModify_ISF_USERS
      Sysdate:         25/Jun/18
      Date and Time:   25/Jun/18, 11:41:59, and 25/Jun/18 11:41:59
      Username:        pvanh (set in TOAD Options, Proc Templates)
      Table Name:      ISF_USERS (set in the "New PL/SQL Object" dialog)
      Trigger Options:  (set in the "New PL/SQL Object" dialog)
******************************************************************************/
BEGIN
   tmpVar := 0;

   :NEW.Last_Modify := SYSDATE;

   EXCEPTION
     WHEN OTHERS THEN
       -- Consider logging the error and then re-raise
       RAISE;
END AutoSet_LastModify_ISF_USERS;
/

