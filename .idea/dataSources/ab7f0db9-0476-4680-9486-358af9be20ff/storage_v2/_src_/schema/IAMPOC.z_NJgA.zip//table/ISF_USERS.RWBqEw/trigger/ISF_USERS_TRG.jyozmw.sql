create trigger ISF_USERS_TRG
  before insert
  on ISF_USERS
  for each row
  BEGIN
   -- For Toad:  Highlight column USERID
   IF :NEW.USERID IS NULL
   THEN
      :new.USERID := ISF_USERS_SEQ.NEXTVAL;
   END IF;
END ISF_USERS_TRG;
/

