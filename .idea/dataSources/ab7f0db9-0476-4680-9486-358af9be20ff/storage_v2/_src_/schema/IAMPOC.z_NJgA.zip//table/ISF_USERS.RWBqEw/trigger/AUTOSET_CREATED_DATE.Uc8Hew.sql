create trigger AUTOSET_CREATED_DATE
  before insert
  on ISF_USERS
  for each row
  DECLARE
   tmpVar   NUMBER;
/******************************************************************************
   NAME:       AUTOSET_CREATED_DATE
   PURPOSE:

   REVISIONS:
   Ver        Date        Author           Description
   ---------  ----------  ---------------  ------------------------------------
   1.0        25/Jun/18      pvanh       1. Created this trigger.

   NOTES:

   Automatically available Auto Replace Keywords:
      Object Name:     AUTOSET_CREATED_DATE
      Sysdate:         25/Jun/18
      Date and Time:   25/Jun/18, 11:55:11, and 25/Jun/18 11:55:11
      Username:        pvanh (set in TOAD Options, Proc Templates)
      Table Name:      ISF_USERS (set in the "New PL/SQL Object" dialog)
      Trigger Options:  (set in the "New PL/SQL Object" dialog)
******************************************************************************/
BEGIN
   tmpVar := 0;

   :NEW.Created_Date := TRUNC (SYSDATE);
   
EXCEPTION
   WHEN OTHERS
   THEN
      -- Consider logging the error and then re-raise
      RAISE;
END AUTOSET_CREATED_DATE;
/

